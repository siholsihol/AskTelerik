﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelerikBlazorGrid_Dapper.DataAccess.Enums
{
    public enum ProductCategory
    {
        Category0,
        Category1,
        Category2,
        Category3,
        Category4,
    }
}
