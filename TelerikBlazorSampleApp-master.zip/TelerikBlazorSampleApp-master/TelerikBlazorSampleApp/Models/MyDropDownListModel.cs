﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TelerikBlazorSampleApp.Models
{
    public class MyDropDownListModel
    {
        public int MyValueField { get; set; }
        public string MyTextField { get; set; }
    }
}
