# MiniatureGolf
MiniatureGolf scoreboard using Blazor (server-side) with Telerik UI for Blazor

[Live-Version on Azure](https://miniaturegolf.azurewebsites.net/ "https://miniaturegolf.azurewebsites.net/"): <br/>
[![Build status](https://marcelgoldstein.visualstudio.com/MiniatureGolf/_apis/build/status/miniaturegolf%20-%201%20-%20CI)](https://marcelgoldstein.visualstudio.com/MiniatureGolf/_build/latest?definitionId=9)



